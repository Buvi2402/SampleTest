package com.sample;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class RandomOrder {

    public static void main(String[] args) {

        WebDriverManager.chromedriver().setup();
        
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        Random random = new Random();

        try {
            driver.get("https://eservices.tn.gov.in/eservicesnew/index.html");
            Thread.sleep(2000);

            Actions action = new Actions(driver);
            WebElement language = driver.findElement(By.xpath("//a[@class='dropbtn']"));
            action.moveToElement(language).perform();
            action.doubleClick();

            WebElement view = driver.findElement(By.xpath("(//div[@class='inr-blk'])[2]"));
            view.click();

            // Run the selection process multiple times
            for (int i = 0; i < 5; i++) { 
                Thread.sleep(1000);

                // Select District
                WebElement dist = driver.findElement(By.id("districtCode"));
                Select Dist = new Select(dist);
                List<WebElement> distOptions = Dist.getOptions();
                int distIndex = getRandomIndex(distOptions.size());
                Dist.selectByIndex(distIndex);
                System.out.println("Selected District Index: " + distIndex);

                Thread.sleep(1000);

                // Select Taluk
                WebElement taluk = driver.findElement(By.id("talukCode"));
                Select Taluk = new Select(taluk);
                List<WebElement> talukOptions = Taluk.getOptions();
                int talukIndex = getRandomIndex(talukOptions.size());
                Taluk.selectByIndex(talukIndex);
                System.out.println("Selected Taluk Index: " + talukIndex);

                Thread.sleep(1000);

                // Select Village
                WebElement village = driver.findElement(By.id("villageCode"));
                Select Village = new Select(village);
                List<WebElement> villageOptions = Village.getOptions();
                int villageIndex = getRandomIndex(villageOptions.size());
                Village.selectByIndex(villageIndex);
                System.out.println("Selected Village Index: " + villageIndex);

                System.out.println("Selection " + (i + 1) + " completed.\n");
            }

        } catch (Exception e) {
            System.out.println("Exception occurred: " + e.getMessage());
        } finally {
            driver.quit();
        }
    }

    private static int getRandomIndex(int size) {
        Random rand = new Random();
        // Avoid selecting index 0, assuming it's usually a placeholder like "--Select--"
        return rand.nextInt(size - 1) + 1;
    }
}

