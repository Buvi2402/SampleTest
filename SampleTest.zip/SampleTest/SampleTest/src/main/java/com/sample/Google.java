package com.sample;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Google {

	public static void main(String[] args) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		try {

			driver.get("https://eservices.tn.gov.in/eservicesnew/index.html");
		    Thread.sleep(2000);  
			Actions action = new Actions(driver);
			
          
            WebElement language = driver.findElement(By.xpath("//a[@class='dropbtn']"));
			action.moveToElement(language).perform();
			action.doubleClick();

			WebElement view = driver.findElement(By.xpath("(//div[@class='inr-blk'])[2]"));
			view.click();
            
			Thread.sleep(1000);
			WebElement dist = driver.findElement(By.id("districtCode"));
			Select s = new Select(dist);
			
		
		    s.selectByIndex(2);
			dist.click();
            System.out.println("District selected Successfully");
            
			Thread.sleep(1000);
			WebElement taluk = driver.findElement(By.id("talukCode"));
			Select s1 = new Select(taluk);
		    s1.selectByIndex(4);
			dist.click();
			System.out.println("Taluk selected Successfully");
			
			Thread.sleep(1000);
			WebElement village = driver.findElement(By.id("villageCode"));
			Select s2 = new Select(village);
		    s2.selectByIndex(2);
			village.click();
			System.out.println("Village selected Successfully");
			

		} catch (Exception e) {
			System.out.println("Exception occured:" + e.getMessage());
		
		}
	}
}
	